-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `group_prototype`
--

DROP TABLE IF EXISTS `group_prototype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_prototype` (
  `group_prototypeid` bigint unsigned NOT NULL,
  `hostid` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `groupid` bigint unsigned DEFAULT NULL,
  `templateid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`group_prototypeid`),
  KEY `group_prototype_1` (`hostid`),
  KEY `group_prototype_2` (`groupid`),
  KEY `group_prototype_3` (`templateid`),
  CONSTRAINT `c_group_prototype_1` FOREIGN KEY (`hostid`) REFERENCES `hosts` (`hostid`) ON DELETE CASCADE,
  CONSTRAINT `c_group_prototype_2` FOREIGN KEY (`groupid`) REFERENCES `hstgrp` (`groupid`),
  CONSTRAINT `c_group_prototype_3` FOREIGN KEY (`templateid`) REFERENCES `group_prototype` (`group_prototypeid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_prototype`
--

LOCK TABLES `group_prototype` WRITE;
/*!40000 ALTER TABLE `group_prototype` DISABLE KEYS */;
INSERT INTO `group_prototype` VALUES (2,10333,'{#DATACENTER.NAME}',NULL,NULL),(4,10334,'{#CLUSTER.NAME} (vm)',NULL,NULL),(6,10334,'{#HV.NAME}',NULL,NULL),(17,10367,'{#DATACENTER.NAME}',NULL,NULL),(19,10368,'{#CLUSTER.NAME} (vm)',NULL,NULL),(21,10368,'{#HV.NAME}',NULL,NULL),(35,10388,'MongoDB sharded cluster/{#REPLICASET}',NULL,NULL),(37,10389,'MongoDB sharded cluster/{#ID}',NULL,NULL),(54,10334,'{#DATACENTER.NAME}/{#VM.FOLDER} (vm)',NULL,NULL),(57,10368,'{#DATACENTER.NAME}/{#VM.FOLDER} (vm)',NULL,NULL),(152,10523,'Consul cluster/{#NODE_DATACENTER}',NULL,NULL),(153,10523,'',19,NULL),(155,10511,'',19,NULL),(156,10512,'',19,NULL),(157,10514,'',19,NULL),(158,10513,'',19,NULL),(159,10333,'',19,NULL),(160,10334,'',19,NULL),(161,10367,'',19,NULL),(162,10368,'',19,NULL),(163,10388,'',20,NULL),(164,10389,'',20,NULL),(166,10511,'{#CLUSTER_HOSTNAME}: Kubernetes/Components: {#COMPONENT.API}',NULL,NULL),(167,10512,'{#CLUSTER_HOSTNAME}: Kubernetes/Components: {#COMPONENT.CONTROLLER}',NULL,NULL),(168,10514,'{#CLUSTER_HOSTNAME}: Kubernetes/Components: {#COMPONENT}',NULL,NULL),(169,10513,'{#CLUSTER_HOSTNAME}: Kubernetes/Components: {#COMPONENT.SCHEDULER}',NULL,NULL),(170,10533,'',6,NULL),(171,10536,'',6,NULL),(172,10537,'',20,NULL),(173,10538,'',19,NULL),(175,10541,'',20,NULL),(176,10545,'',20,NULL),(177,10549,'',19,NULL),(178,10550,'',19,NULL),(179,10550,'{#REGION}',NULL,NULL),(180,10554,'',19,NULL),(181,10554,'Control-M/{#SERVER.NAME}',NULL,NULL),(182,10559,'',20,NULL),(183,10567,'',19,NULL),(184,10567,'{#CLUSTER_HOSTNAME}: Kubernetes/Nodes/Role: {#ROLES}',NULL,NULL),(185,10569,'',20,NULL),(186,10578,'',20,NULL),(187,10579,'',20,NULL),(188,10580,'',20,NULL),(189,10581,'',6,NULL),(190,10585,'',19,NULL),(191,10588,'',6,NULL),(192,10592,'',19,NULL),(193,10592,'Cisco SD-WAN/{#TYPE}',NULL,NULL),(194,10597,'',19,NULL),(195,10598,'',19,NULL),(196,10601,'',19,NULL),(197,10608,'',19,NULL),(198,10612,'',20,NULL),(199,10621,'',19,NULL),(200,10622,'',19,NULL),(201,10623,'',6,NULL),(202,10624,'',20,NULL),(203,10625,'',19,NULL),(204,10626,'',19,NULL),(205,10333,'{#CLUSTER.NAME} (hypervisor)',NULL,NULL),(206,10367,'{#CLUSTER.NAME} (hypervisor)',NULL,NULL),(207,10633,'',19,NULL),(208,10635,'',6,NULL),(209,10643,'',19,NULL),(210,10644,'',19,NULL),(211,10654,'',20,NULL);
/*!40000 ALTER TABLE `group_prototype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:04

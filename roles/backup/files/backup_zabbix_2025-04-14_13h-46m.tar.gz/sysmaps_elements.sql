-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sysmaps_elements`
--

DROP TABLE IF EXISTS `sysmaps_elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmaps_elements` (
  `selementid` bigint unsigned NOT NULL,
  `sysmapid` bigint unsigned NOT NULL,
  `elementid` bigint unsigned NOT NULL DEFAULT '0',
  `elementtype` int NOT NULL DEFAULT '0',
  `iconid_off` bigint unsigned DEFAULT NULL,
  `iconid_on` bigint unsigned DEFAULT NULL,
  `label` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `label_location` int NOT NULL DEFAULT '-1',
  `x` int NOT NULL DEFAULT '0',
  `y` int NOT NULL DEFAULT '0',
  `iconid_disabled` bigint unsigned DEFAULT NULL,
  `iconid_maintenance` bigint unsigned DEFAULT NULL,
  `elementsubtype` int NOT NULL DEFAULT '0',
  `areatype` int NOT NULL DEFAULT '0',
  `width` int NOT NULL DEFAULT '200',
  `height` int NOT NULL DEFAULT '200',
  `viewtype` int NOT NULL DEFAULT '0',
  `use_iconmap` int NOT NULL DEFAULT '1',
  `evaltype` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`selementid`),
  KEY `sysmaps_elements_1` (`sysmapid`),
  KEY `sysmaps_elements_2` (`iconid_off`),
  KEY `sysmaps_elements_3` (`iconid_on`),
  KEY `sysmaps_elements_4` (`iconid_disabled`),
  KEY `sysmaps_elements_5` (`iconid_maintenance`),
  CONSTRAINT `c_sysmaps_elements_1` FOREIGN KEY (`sysmapid`) REFERENCES `sysmaps` (`sysmapid`) ON DELETE CASCADE,
  CONSTRAINT `c_sysmaps_elements_2` FOREIGN KEY (`iconid_off`) REFERENCES `images` (`imageid`),
  CONSTRAINT `c_sysmaps_elements_3` FOREIGN KEY (`iconid_on`) REFERENCES `images` (`imageid`),
  CONSTRAINT `c_sysmaps_elements_4` FOREIGN KEY (`iconid_disabled`) REFERENCES `images` (`imageid`),
  CONSTRAINT `c_sysmaps_elements_5` FOREIGN KEY (`iconid_maintenance`) REFERENCES `images` (`imageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmaps_elements`
--

LOCK TABLES `sysmaps_elements` WRITE;
/*!40000 ALTER TABLE `sysmaps_elements` DISABLE KEYS */;
INSERT INTO `sysmaps_elements` VALUES (2,2,10084,0,187,NULL,'{HOST.NAME}\r\n10.68.7.16\r\nUptime: {?last(/{HOST.HOST}/system.uptime)}\r\nCPU utilization: {?last(/{HOST.HOST}/system.cpu.util)}\r\nAvailable memory: {?last(/{HOST.HOST}/vm.memory.size[pavailable])}',-1,787,682,NULL,NULL,0,0,200,200,0,0,0),(3,2,10665,0,150,NULL,'{HOST.NAME}\r\n{HOST.IP}\r\nUptime: {?last(/{HOST.HOST}/system.uptime)}\r\nCPU utilization: {?last(/{HOST.HOST}/system.cpu.util)}\r\nAvailable memory: {?last(/{HOST.HOST}/vm.memory.size[pavailable])}',-1,200,223,NULL,NULL,0,0,200,200,0,0,0),(4,2,10666,0,150,NULL,'{HOST.NAME}\r\n{HOST.IP}\r\nUptime: {?last(/{HOST.HOST}/system.uptime)}\r\nCPU utilization: {?last(/{HOST.HOST}/system.cpu.util)}\r\nAvailable memory: {?last(/{HOST.HOST}/vm.memory.size[pavailable])}',-1,461,23,NULL,NULL,0,0,200,200,0,0,0),(5,2,10667,0,150,NULL,'{HOST.NAME}\r\n{HOST.IP}\r\nUptime: {?last(/{HOST.HOST}/system.uptime)}\r\nCPU utilization: {?last(/{HOST.HOST}/system.cpu.util)}\r\nAvailable memory: {?last(/{HOST.HOST}/vm.memory.size[pavailable])}',-1,461,550,NULL,NULL,0,0,200,200,0,0,0),(6,2,10669,0,150,NULL,'{HOST.NAME}\r\n{HOST.IP}\r\nUptime: {?last(/{HOST.HOST}/system.uptime)}\r\nCPU utilization: {?last(/{HOST.HOST}/system.cpu.util)}\r\nAvailable memory: {?last(/{HOST.HOST}/vm.memory.size[pavailable])}',-1,811,223,NULL,NULL,0,0,200,200,0,0,0),(7,2,10670,0,150,NULL,'{HOST.NAME}\r\n{HOST.IP}\r\nUptime: {?last(/{HOST.HOST}/system.uptime)}\r\nCPU utilization: {?last(/{HOST.HOST}/system.cpu.util)}\r\nAvailable memory: {?last(/{HOST.HOST}/vm.memory.size[pavailable])}',-1,990,130,NULL,NULL,0,0,200,200,0,0,0),(8,2,10668,0,150,NULL,'{HOST.NAME}\r\n{HOST.IP}\r\nUptime: {?last(/{HOST.HOST}/system.uptime)}\r\nCPU utilization: {?last(/{HOST.HOST}/system.cpu.util)}\r\nAvailable memory: {?last(/{HOST.HOST}/vm.memory.size[pavailable])}',-1,200,660,NULL,NULL,0,0,200,200,0,0,0),(9,2,10671,0,150,NULL,'{HOST.NAME}\r\n{HOST.IP}\r\nUptime: {?last(/{HOST.HOST}/system.uptime)}\r\nCPU utilization: {?last(/{HOST.HOST}/system.cpu.util)}\r\nAvailable memory: {?last(/{HOST.HOST}/vm.memory.size[pavailable])}',-1,461,280,NULL,NULL,0,0,200,200,0,0,0);
/*!40000 ALTER TABLE `sysmaps_elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:19

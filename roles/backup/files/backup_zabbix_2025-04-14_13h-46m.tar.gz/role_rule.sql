-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `role_rule`
--

DROP TABLE IF EXISTS `role_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_rule` (
  `role_ruleid` bigint unsigned NOT NULL,
  `roleid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `value_int` int NOT NULL DEFAULT '0',
  `value_str` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `value_moduleid` bigint unsigned DEFAULT NULL,
  `value_serviceid` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`role_ruleid`),
  KEY `role_rule_1` (`roleid`),
  KEY `role_rule_2` (`value_moduleid`),
  KEY `role_rule_3` (`value_serviceid`),
  CONSTRAINT `c_role_rule_1` FOREIGN KEY (`roleid`) REFERENCES `role` (`roleid`) ON DELETE CASCADE,
  CONSTRAINT `c_role_rule_2` FOREIGN KEY (`value_moduleid`) REFERENCES `module` (`moduleid`) ON DELETE CASCADE,
  CONSTRAINT `c_role_rule_3` FOREIGN KEY (`value_serviceid`) REFERENCES `services` (`serviceid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_rule`
--

LOCK TABLES `role_rule` WRITE;
/*!40000 ALTER TABLE `role_rule` DISABLE KEYS */;
INSERT INTO `role_rule` VALUES (1,1,0,'ui.default_access',1,'',NULL,NULL),(2,1,0,'services.read',1,'',NULL,NULL),(3,1,0,'services.write',0,'',NULL,NULL),(4,1,0,'modules.default_access',1,'',NULL,NULL),(5,1,0,'api.access',1,'',NULL,NULL),(6,1,0,'api.mode',0,'',NULL,NULL),(7,1,0,'actions.default_access',1,'',NULL,NULL),(8,2,0,'ui.default_access',1,'',NULL,NULL),(9,2,0,'services.read',1,'',NULL,NULL),(10,2,0,'services.write',1,'',NULL,NULL),(11,2,0,'modules.default_access',1,'',NULL,NULL),(12,2,0,'api.access',1,'',NULL,NULL),(13,2,0,'api.mode',0,'',NULL,NULL),(14,2,0,'actions.default_access',1,'',NULL,NULL),(15,3,0,'ui.default_access',1,'',NULL,NULL),(16,3,0,'services.read',1,'',NULL,NULL),(17,3,0,'services.write',1,'',NULL,NULL),(18,3,0,'modules.default_access',1,'',NULL,NULL),(19,3,0,'api.access',1,'',NULL,NULL),(20,3,0,'api.mode',0,'',NULL,NULL),(21,3,0,'actions.default_access',1,'',NULL,NULL),(22,4,0,'ui.default_access',1,'',NULL,NULL),(23,4,0,'services.read',1,'',NULL,NULL),(24,4,0,'services.write',0,'',NULL,NULL),(25,4,0,'modules.default_access',1,'',NULL,NULL),(26,4,0,'api.access',0,'',NULL,NULL),(27,4,0,'actions.default_access',0,'',NULL,NULL);
/*!40000 ALTER TABLE `role_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:18

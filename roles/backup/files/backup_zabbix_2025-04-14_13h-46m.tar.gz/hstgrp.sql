-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hstgrp`
--

DROP TABLE IF EXISTS `hstgrp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hstgrp` (
  `groupid` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `flags` int NOT NULL DEFAULT '0',
  `uuid` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`groupid`),
  UNIQUE KEY `hstgrp_1` (`type`,`name`),
  KEY `hstgrp_2` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hstgrp`
--

LOCK TABLES `hstgrp` WRITE;
/*!40000 ALTER TABLE `hstgrp` DISABLE KEYS */;
INSERT INTO `hstgrp` VALUES (1,'Templates',0,'7df96b18c230490a9a0a9e2307226338',1),(2,'Linux servers',0,'dc579cd7a1a34222933f24f52a68bcd8',0),(4,'Zabbix servers',0,'6f6799aa69e844b4b3918f779f2abf08',0),(5,'Discovered hosts',0,'f2481361f99448eea617b7b1d4765566',0),(6,'Virtual machines',0,'137f19e6e2dc4219b33553b812627bc2',0),(7,'Hypervisors',0,'1b837a3c078647049a0c00c61b4d57b5',0),(9,'Templates/Network devices',0,'36bff6c29af64692839d077febfc7079',1),(10,'Templates/Operating systems',0,'846977d1dfed4968bc5f8bdb363285bc',1),(11,'Templates/Server hardware',0,'e960332b3f6c46a1956486d4f3f99fce',1),(12,'Templates/Applications',0,'a571c0d144b14fd4a87a9d9b2aa9fcd6',1),(13,'Templates/Databases',0,'748ad4d098d447d492bb935c907f652f',1),(14,'Templates/Virtualization',0,'02e4df4f20b848e79267641790f241da',1),(15,'Templates/Telephony',0,'1d12408342854fd5a4436dd6d5d1bd4a',1),(16,'Templates/SAN',0,'7c2cb727f85b492d88cd56e17127c64d',1),(17,'Templates/Video surveillance',0,'d37f71c7e3f7469bab645852a69a2018',1),(18,'Templates/Power',0,'3dcd5bbe90534f9e8eb5c2d53756af63',1),(19,'Applications',0,'a571c0d144b14fd4a87a9d9b2aa9fcd6',0),(20,'Databases',0,'748ad4d098d447d492bb935c907f652f',0),(21,'Templates/Cloud',0,'c2c162144c2d4c5491c8801193af4945',1);
/*!40000 ALTER TABLE `hstgrp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:13

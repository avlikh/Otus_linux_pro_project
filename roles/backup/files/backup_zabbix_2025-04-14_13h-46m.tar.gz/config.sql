-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `config` (
  `configid` bigint unsigned NOT NULL,
  `work_period` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '1-5,09:00-18:00',
  `alert_usrgrpid` bigint unsigned DEFAULT NULL,
  `default_theme` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'blue-theme',
  `authentication_type` int NOT NULL DEFAULT '0',
  `discovery_groupid` bigint unsigned DEFAULT NULL,
  `max_in_table` int NOT NULL DEFAULT '50',
  `search_limit` int NOT NULL DEFAULT '1000',
  `severity_color_0` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '97AAB3',
  `severity_color_1` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '7499FF',
  `severity_color_2` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'FFC859',
  `severity_color_3` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'FFA059',
  `severity_color_4` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'E97659',
  `severity_color_5` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'E45959',
  `severity_name_0` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'Not classified',
  `severity_name_1` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'Information',
  `severity_name_2` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'Warning',
  `severity_name_3` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'Average',
  `severity_name_4` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'High',
  `severity_name_5` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'Disaster',
  `ok_period` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '5m',
  `blink_period` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '2m',
  `problem_unack_color` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'CC0000',
  `problem_ack_color` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'CC0000',
  `ok_unack_color` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '009900',
  `ok_ack_color` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '009900',
  `problem_unack_style` int NOT NULL DEFAULT '1',
  `problem_ack_style` int NOT NULL DEFAULT '1',
  `ok_unack_style` int NOT NULL DEFAULT '1',
  `ok_ack_style` int NOT NULL DEFAULT '1',
  `snmptrap_logging` int NOT NULL DEFAULT '1',
  `server_check_interval` int NOT NULL DEFAULT '10',
  `hk_events_mode` int NOT NULL DEFAULT '1',
  `hk_events_trigger` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '365d',
  `hk_events_internal` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '1d',
  `hk_events_discovery` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '1d',
  `hk_events_autoreg` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '1d',
  `hk_services_mode` int NOT NULL DEFAULT '1',
  `hk_services` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '365d',
  `hk_audit_mode` int NOT NULL DEFAULT '1',
  `hk_audit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '31d',
  `hk_sessions_mode` int NOT NULL DEFAULT '1',
  `hk_sessions` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '365d',
  `hk_history_mode` int NOT NULL DEFAULT '1',
  `hk_history_global` int NOT NULL DEFAULT '0',
  `hk_history` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '31d',
  `hk_trends_mode` int NOT NULL DEFAULT '1',
  `hk_trends_global` int NOT NULL DEFAULT '0',
  `hk_trends` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '365d',
  `default_inventory_mode` int NOT NULL DEFAULT '-1',
  `custom_color` int NOT NULL DEFAULT '0',
  `http_auth_enabled` int NOT NULL DEFAULT '0',
  `http_login_form` int NOT NULL DEFAULT '0',
  `http_strip_domains` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `http_case_sensitive` int NOT NULL DEFAULT '1',
  `ldap_auth_enabled` int NOT NULL DEFAULT '0',
  `ldap_case_sensitive` int NOT NULL DEFAULT '1',
  `db_extension` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `autoreg_tls_accept` int NOT NULL DEFAULT '1',
  `compression_status` int NOT NULL DEFAULT '0',
  `compress_older` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '7d',
  `instanceid` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `saml_auth_enabled` int NOT NULL DEFAULT '0',
  `saml_case_sensitive` int NOT NULL DEFAULT '0',
  `default_lang` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'en_US',
  `default_timezone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'system',
  `login_attempts` int NOT NULL DEFAULT '5',
  `login_block` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '30s',
  `show_technical_errors` int NOT NULL DEFAULT '0',
  `validate_uri_schemes` int NOT NULL DEFAULT '1',
  `uri_valid_schemes` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'http,https,ftp,file,mailto,tel,ssh',
  `x_frame_options` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'SAMEORIGIN',
  `iframe_sandboxing_enabled` int NOT NULL DEFAULT '1',
  `iframe_sandboxing_exceptions` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `max_overview_table_size` int NOT NULL DEFAULT '50',
  `history_period` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '24h',
  `period_default` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '1h',
  `max_period` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '2y',
  `socket_timeout` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '3s',
  `connect_timeout` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '3s',
  `media_type_test_timeout` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '65s',
  `script_timeout` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '60s',
  `item_test_timeout` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '60s',
  `session_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `report_test_timeout` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '60s',
  `dbversion_status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `hk_events_service` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '1d',
  `passwd_min_length` int NOT NULL DEFAULT '8',
  `passwd_check_rules` int NOT NULL DEFAULT '8',
  `auditlog_enabled` int NOT NULL DEFAULT '1',
  `ha_failover_delay` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '1m',
  `geomaps_tile_provider` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `geomaps_tile_url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `geomaps_max_zoom` int NOT NULL DEFAULT '0',
  `geomaps_attribution` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `vault_provider` int NOT NULL DEFAULT '0',
  `ldap_userdirectoryid` bigint unsigned DEFAULT NULL,
  `server_status` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `jit_provision_interval` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '1h',
  `saml_jit_status` int NOT NULL DEFAULT '0',
  `ldap_jit_status` int NOT NULL DEFAULT '0',
  `disabled_usrgrpid` bigint unsigned DEFAULT NULL,
  `timeout_zabbix_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '3s',
  `timeout_simple_check` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '3s',
  `timeout_snmp_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '3s',
  `timeout_external_check` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '3s',
  `timeout_db_monitor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '3s',
  `timeout_http_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '3s',
  `timeout_ssh_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '3s',
  `timeout_telnet_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '3s',
  `timeout_script` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '3s',
  `auditlog_mode` int NOT NULL DEFAULT '1',
  `mfa_status` int NOT NULL DEFAULT '0',
  `mfaid` bigint unsigned DEFAULT NULL,
  `software_update_checkid` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `software_update_check_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `timeout_browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '60s',
  PRIMARY KEY (`configid`),
  KEY `config_1` (`alert_usrgrpid`),
  KEY `config_2` (`discovery_groupid`),
  KEY `config_3` (`ldap_userdirectoryid`),
  KEY `config_4` (`disabled_usrgrpid`),
  KEY `config_5` (`mfaid`),
  CONSTRAINT `c_config_1` FOREIGN KEY (`alert_usrgrpid`) REFERENCES `usrgrp` (`usrgrpid`),
  CONSTRAINT `c_config_2` FOREIGN KEY (`discovery_groupid`) REFERENCES `hstgrp` (`groupid`),
  CONSTRAINT `c_config_3` FOREIGN KEY (`ldap_userdirectoryid`) REFERENCES `userdirectory` (`userdirectoryid`),
  CONSTRAINT `c_config_4` FOREIGN KEY (`disabled_usrgrpid`) REFERENCES `usrgrp` (`usrgrpid`),
  CONSTRAINT `c_config_5` FOREIGN KEY (`mfaid`) REFERENCES `mfa` (`mfaid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'1-5,09:00-18:00',7,'blue-theme',0,5,50,1000,'97AAB3','7499FF','FFC859','FFA059','E97659','E45959','Not classified','Information','Warning','Average','High','Disaster','5m','2m','CC0000','CC0000','009900','009900',1,1,1,1,1,10,1,'365d','1d','1d','1d',1,'365d',1,'31d',1,'365d',1,0,'31d',1,0,'365d',-1,0,0,0,'',1,0,1,'',1,0,'7d','396aeda2f978abc63c0674594f810611',0,0,'en_US','Europe/Moscow',5,'30s',0,1,'http,https,ftp,file,mailto,tel,ssh','SAMEORIGIN',1,'',50,'24h','1h','2y','3s','3s','65s','60s','60s','9669ae6cacbb886e4579af178f712abd','','60s','[{\"database\":\"MySQL\",\"current_version\":\"8.00.41\",\"min_version\":\"5.07.28\",\"max_version\":\"9.00.x\",\"history_pk\":1,\"min_supported_version\":\"8.00.30\",\"flag\":0}]','1d',8,8,1,'1m','OpenStreetMap.Mapnik','',0,'',0,NULL,'{\"version\":\"7.2.5\",\"configuration\":{\"enable_global_scripts\":true,\"allow_software_update_check\":true}}','1h',0,0,NULL,'3s','3s','3s','3s','3s','3s','3s','3s','3s',1,0,NULL,'c83b706ece370bd85387083400739dd4','{\"lastcheck\":1744609995,\"lastcheck_success\":1744609995,\"nextcheck\":1744638795,\"versions\":[{\"version\":\"5.0\",\"end_of_full_support\":true,\"latest_release\":{\"created\":\"1737965207\",\"release\":\"5.0.46\"}},{\"version\":\"6.0\",\"end_of_full_support\":true,\"latest_release\":{\"created\":\"1740384594\",\"release\":\"6.0.39\"}},{\"version\":\"6.4\",\"end_of_full_support\":true,\"latest_release\":{\"created\":\"1737976274\",\"release\":\"6.4.21\"}},{\"version\":\"7.0\",\"end_of_full_support\":false,\"latest_release\":{\"created\":\"1743063404\",\"release\":\"7.0.11\"}},{\"version\":\"7.2\",\"end_of_full_support\":false,\"latest_release\":{\"created\":\"1743073608\",\"release\":\"7.2.5\"}}]}','60s');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:02

-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lld_override_opdiscover`
--

DROP TABLE IF EXISTS `lld_override_opdiscover`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_opdiscover` (
  `lld_override_operationid` bigint unsigned NOT NULL,
  `discover` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`lld_override_operationid`),
  CONSTRAINT `c_lld_override_opdiscover_1` FOREIGN KEY (`lld_override_operationid`) REFERENCES `lld_override_operation` (`lld_override_operationid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_opdiscover`
--

LOCK TABLES `lld_override_opdiscover` WRITE;
/*!40000 ALTER TABLE `lld_override_opdiscover` DISABLE KEYS */;
INSERT INTO `lld_override_opdiscover` VALUES (4539,0),(4540,0),(4541,0),(4542,0),(4543,1),(4544,1),(4545,1),(4546,1),(4547,1),(4548,1),(4549,0),(4550,0),(4551,0),(4552,0),(4553,0),(4554,0),(4555,0),(4556,0),(4557,0),(4558,0),(4559,0),(4560,0),(4561,0),(4562,0),(4563,0),(4564,0),(4565,1),(4566,1),(4567,0),(4568,1),(4569,1),(4570,1),(4581,1),(4582,0),(4583,0),(4584,0),(4585,1),(4586,0),(4587,0),(4588,0),(4589,0),(4590,1),(4591,1),(4592,1),(4593,1),(4594,1),(4595,1),(4596,1),(4597,1),(4598,1),(4599,1),(4600,1),(4601,1),(4602,1),(4603,1),(4604,1),(4605,1),(4606,1),(4607,1),(4608,1),(4609,1),(4610,1),(4611,1),(4612,1),(4613,1),(4614,0),(4615,1),(4616,1),(4617,1),(4618,1),(4619,1),(4620,1),(4621,1),(4622,1),(4629,1),(4633,1),(4634,1),(4635,1),(4636,1),(4637,1),(4638,1),(4639,1),(4640,1),(4641,1),(4642,1),(4643,1),(4644,1),(4645,1),(4646,1),(4647,1),(4648,1),(4649,1),(4650,1),(4651,1),(4652,1),(4653,1),(4654,1),(4655,0),(4656,0),(4657,1),(4658,1),(4659,1),(4660,1),(4661,1),(4662,1),(4663,1),(4664,0),(4665,1),(4666,0),(4667,0),(4668,0),(4669,0),(4670,0),(4671,0),(4672,1),(4673,0),(4674,0),(4675,0),(4676,1),(4677,0),(4678,0),(4679,0),(4680,0),(4681,0),(4682,0),(4683,1),(4684,0),(4685,0),(4688,1),(4689,1),(4690,1),(4691,1),(4692,1),(4693,1),(4694,0),(4695,1),(4697,1),(4699,1),(4700,1),(4701,1),(4702,1),(4703,1),(4704,1),(4705,1),(4706,1),(4707,1),(4708,1),(4712,1),(4713,1),(4714,1),(4718,1),(4722,1),(4723,1),(4724,1),(4729,1),(4730,1),(4731,1),(4732,1),(4733,1),(4734,1),(4735,1);
/*!40000 ALTER TABLE `lld_override_opdiscover` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:15

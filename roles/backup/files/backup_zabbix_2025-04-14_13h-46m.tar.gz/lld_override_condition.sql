-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lld_override_condition`
--

DROP TABLE IF EXISTS `lld_override_condition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_condition` (
  `lld_override_conditionid` bigint unsigned NOT NULL,
  `lld_overrideid` bigint unsigned NOT NULL,
  `operator` int NOT NULL DEFAULT '8',
  `macro` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`lld_override_conditionid`),
  KEY `lld_override_condition_1` (`lld_overrideid`),
  CONSTRAINT `c_lld_override_condition_1` FOREIGN KEY (`lld_overrideid`) REFERENCES `lld_override` (`lld_overrideid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_condition`
--

LOCK TABLES `lld_override_condition` WRITE;
/*!40000 ALTER TABLE `lld_override_condition` DISABLE KEYS */;
INSERT INTO `lld_override_condition` VALUES (4131,4383,8,'{#TYPE}','aggregated_status'),(4132,4384,8,'{#TYPE}','service_check'),(4133,4385,8,'{#GRPC.CODE}','{$ETCD.GRPC_CODE.TRIGGER.MATCHES}'),(4134,4386,8,'{#MODE}','tcp'),(4135,4387,8,'{#MODE}','tcp'),(4136,4388,8,'{#MODE}','tcp'),(4137,4389,8,'{#MODE}','tcp'),(4138,4390,8,'{#MODE}','tcp'),(4139,4391,8,'{#MODE}','tcp'),(4140,4392,8,'{#TYPE}','buckets'),(4141,4393,8,'{#TYPE}','totals'),(4142,4394,8,'{#TYPE}','buckets'),(4143,4395,8,'{#TYPE}','totals'),(4144,4396,8,'{#TYPE}','buckets'),(4145,4397,8,'{#TYPE}','totals'),(4146,4398,8,'{#TYPE}','buckets'),(4147,4399,8,'{#TYPE}','totals'),(4148,4400,8,'{#ENDPOINT}','zabbix-agent.*'),(4149,4401,8,'{#TYPE}','buckets'),(4150,4402,8,'{#TYPE}','totals'),(4151,4403,8,'{#TYPE}','buckets'),(4152,4404,8,'{#TYPE}','totals'),(4153,4405,8,'{#TYPE}','buckets'),(4154,4406,8,'{#TYPE}','totals'),(4155,4407,12,'{#IS_SUM}',''),(4156,4408,12,'{#SINGLETON}',''),(4157,4409,9,'{#CHANNEL_ID}','{$HIKVISION_MAIN_CHANNEL_ID}'),(4158,4410,8,'{#TYPE}','Microsoft.DBforMySQL/flexibleServers'),(4159,4411,8,'{#TYPE}','Microsoft.DBforMySQL/servers'),(4160,4412,8,'{#TYPE}','Microsoft.DBforPostgreSQL/flexibleServers'),(4161,4413,8,'{#TYPE}','Microsoft.DBforPostgreSQL/servers'),(4164,4416,8,'{#VERSION}','^MongoDB$'),(4165,4417,8,'{#CLOUD_SQL.INSTANCE.TYPE}','READ_REPLICA_INSTANCE'),(4166,4417,12,'{#CLOUD_SQL.MASTER}',''),(4167,4418,8,'{#CLOUD_SQL.INSTANCE.TYPE}','READ_REPLICA_INSTANCE'),(4168,4418,12,'{#CLOUD_SQL.MASTER}',''),(4169,4419,8,'{#CLOUD_SQL.INSTANCE.TYPE}','READ_REPLICA_INSTANCE'),(4170,4419,12,'{#CLOUD_SQL.MASTER}',''),(4171,4420,8,'{#NODE_STATE}','7'),(4172,4421,8,'{#NODE_STATE}','1'),(4173,4422,8,'{#TYPE}','miss_peer_region_count'),(4174,4423,8,'{#TYPE}','down_peer_region_count'),(4175,4424,8,'{#TYPE}','failed'),(4176,4425,8,'{#TYPE}','unreachable'),(4177,4426,8,'{#THRESHOLD_LO_WARN}','^$'),(4178,4427,8,'{#THRESHOLD_LO_CRIT}','^$'),(4179,4428,8,'{#THRESHOLD_HI_WARN}','^$'),(4180,4429,8,'{#THRESHOLD_HI_CRIT}','^$'),(4181,4430,8,'{#THRESHOLD_LO_WARN}','^$'),(4182,4431,8,'{#THRESHOLD_LO_CRIT}','^$'),(4183,4432,8,'{#THRESHOLD_HI_WARN}','^$'),(4184,4433,8,'{#THRESHOLD_HI_CRIT}','^$'),(4185,4434,8,'{#THRESHOLD_LO_WARN}','^$'),(4186,4435,8,'{#THRESHOLD_LO_CRIT}','^$'),(4187,4436,8,'{#THRESHOLD_HI_WARN}','^$'),(4188,4437,8,'{#THRESHOLD_HI_CRIT}','^$'),(4189,4438,9,'{#CISCO.IF.NAME}','{$CISCO.LLD.FILTER.IF.CONTROL.MATCHES}'),(4190,4439,8,'{#PART.NAME}','{$BIGIP.LLD.OVERRIDE.PART.FILTER_LOW_SPACE_TRIGGER}'),(4191,4440,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4192,4441,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4193,4442,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4194,4443,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4195,4444,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4196,4445,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4197,4446,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4198,4447,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4199,4448,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4200,4449,8,'{#ZYXEL.IF.NAME}','.*'),(4201,4450,8,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4202,4451,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4203,4452,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4204,4453,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4205,4454,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4206,4455,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4207,4456,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4208,4457,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4209,4458,9,'{#ZYXEL.IF.NAME}','{$ZYXEL.LLD.FILTER.IF.CONTROL.MATCHES}'),(4210,4459,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4211,4460,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4212,4461,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4213,4462,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4214,4463,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4215,4464,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4216,4465,12,'{#FSOPTIONS}',''),(4217,4465,8,'{#FSOPTIONS}','(?:^|,)noowners\\b'),(4218,4465,8,'{#FSOPTIONS}','(?:^|,)read-only\\b'),(4219,4465,8,'{#FSTYPE}','hfs'),(4220,4466,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4221,4467,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4222,4468,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4223,4469,8,'{#EXTERNAL_SENSOR1_NAME}','Temp'),(4224,4470,8,'{#EXTERNAL_SENSOR2_NAME}','Temp'),(4225,4471,8,'{#EXTERNAL_SENSOR1_NAME}','Temp'),(4226,4472,8,'{#EXTERNAL_SENSOR2_NAME}','Temp'),(4227,4473,8,'{#EXTERNAL_SENSOR1_NAME}','Temp'),(4228,4474,8,'{#EXTERNAL_SENSOR2_NAME}','Temp'),(4229,4475,8,'{#EXTERNAL_SENSOR1_NAME}','Temp'),(4230,4476,8,'{#EXTERNAL_SENSOR2_NAME}','Temp'),(4231,4477,8,'{#EXTERNAL_SENSOR1_NAME}','Temp'),(4232,4478,8,'{#EXTERNAL_SENSOR2_NAME}','Temp'),(4233,4479,8,'{#EXTERNAL_SENSOR1_NAME}','Temp'),(4234,4480,8,'{#EXTERNAL_SENSOR2_NAME}','Temp'),(4235,4481,8,'{#EXTERNAL_SENSOR1_NAME}','Temp'),(4236,4482,8,'{#EXTERNAL_SENSOR2_NAME}','Temp'),(4237,4483,8,'{#EXTERNAL_SENSOR1_NAME}','Temp'),(4238,4484,8,'{#EXTERNAL_SENSOR2_NAME}','Temp'),(4239,4485,8,'{#EXTERNAL_SENSOR1_NAME}','Temp'),(4240,4486,8,'{#EXTERNAL_SENSOR2_NAME}','Temp'),(4241,4487,8,'{#EXTERNAL_SENSOR1_NAME}','Temp'),(4242,4488,8,'{#EXTERNAL_SENSOR2_NAME}','Temp'),(4243,4489,8,'{#EXTERNAL_SENSOR1_NAME}','Temp'),(4244,4490,8,'{#EXTERNAL_SENSOR2_NAME}','Temp'),(4245,4491,8,'{#TYPE}','8'),(4246,4492,8,'{#TYPE}','8'),(4247,4493,8,'{#FSTYPE}','3|4'),(4248,4500,8,'{#ATTRIBUTES}','Bad_Block_Rate'),(4249,4501,9,'{#DISKTYPE}','nvme'),(4250,4502,8,'{#ATTRIBUTES}','Power_Cycle_Count'),(4251,4503,8,'{#ATTRIBUTES}','Program_Fail_Count_Chip'),(4252,4504,8,'{#ATTRIBUTES}','Raw_Read_Error_Rate'),(4253,4505,8,'{#ATTRIBUTES}','Reallocated_Sector_Ct'),(4254,4506,8,'{#ATTRIBUTES}','Reported_Uncorrect'),(4255,4507,8,'{#ATTRIBUTES}','Seek_Error_Rate'),(4256,4508,8,'{#DISKTYPE}','nvme'),(4257,4509,8,'{#ATTRIBUTES}','Spin_Up_Time'),(4258,4510,8,'{#ATTRIBUTES}','Start_Stop_Count'),(4259,4511,8,'{#ATTRIBUTES}','Bad_Block_Rate'),(4260,4512,9,'{#DISKTYPE}','nvme'),(4261,4513,8,'{#ATTRIBUTES}','Power_Cycle_Count'),(4262,4514,8,'{#ATTRIBUTES}','Program_Fail_Count_Chip'),(4263,4515,8,'{#ATTRIBUTES}','Raw_Read_Error_Rate'),(4264,4516,8,'{#ATTRIBUTES}','Reallocated_Sector_Ct'),(4265,4517,8,'{#ATTRIBUTES}','Reported_Uncorrect'),(4266,4518,8,'{#ATTRIBUTES}','Seek_Error_Rate'),(4267,4519,8,'{#DISKTYPE}','nvme'),(4268,4520,8,'{#ATTRIBUTES}','Spin_Up_Time'),(4269,4521,8,'{#ATTRIBUTES}','Start_Stop_Count'),(4270,4522,8,'{#AWS.ECS.CLUSTER.INFRASTRUCTURE}','^serverless$'),(4271,4523,8,'{#AWS.ECS.CLUSTER.INFRASTRUCTURE}','^use_ecs2$'),(4272,4524,8,'{#TYPE}','^(cloud_service_status|platform|other)$'),(4273,4525,8,'{#DRIVE_TYPE}','SSD'),(4274,4526,8,'{#RECOVERY_MODEL}','3'),(4275,4527,8,'{#AWS.ELB.TYPE}','^application$'),(4276,4528,8,'{#RECOVERY_MODEL}','3'),(4277,4529,8,'{#AWS.ELB.TYPE}','^network$'),(4278,4530,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4279,4531,8,'{#VMWARE.ALARMS.STATUS}','red'),(4280,4532,8,'{#VMWARE.ALARMS.STATUS}','yellow'),(4281,4533,8,'{#VMWARE.ALARMS.STATUS}','green'),(4282,4534,8,'{#DATASTORE.TYPE}','vsan|nfs'),(4283,4535,8,'{#DATASTORE.TYPE}','vsan|nfs'),(4284,4536,8,'{#DATASTORE.TYPE}','vsan'),(4285,4537,8,'{#VMWARE.ALARMS.STATUS}','red'),(4286,4538,8,'{#VMWARE.ALARMS.STATUS}','yellow'),(4287,4539,8,'{#VMWARE.ALARMS.STATUS}','green'),(4288,4540,8,'{#DATASTORE.TYPE}','vsan|nfs'),(4289,4541,12,'{#PROXY.GROUP}',''),(4290,4542,12,'{#PROXY.GROUP}',''),(4291,4543,12,'{#PROXY.GROUP}',''),(4292,4544,8,'{#HAMODE}','^Active-Passive$'),(4293,4545,9,'{#IFSPEED}','\\d+'),(4294,4546,9,'{#IFZONE}','^null$'),(4295,4547,12,'{#PROXY.GROUP}',''),(4296,4548,12,'{#PROXY.GROUP}',''),(4297,4415,8,'{#VERSION}','^(?=.*serverless)(?=.*vcore).*$'),(4298,4414,8,'{#VERSION}','^(?!.*serverless)(?=.*vcore).*$'),(4299,4549,8,'{#VERSION}','^(?!.*serverless)(?!.*vcore).*$'),(4300,4550,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4301,4551,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4302,4552,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4303,4553,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4304,4554,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4305,4555,8,'{#FSTYPE}','^(btrfs|zfs)$'),(4306,4556,8,'{#FSTYPE}','^(btrfs|zfs)$');
/*!40000 ALTER TABLE `lld_override_condition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:15

-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lld_override`
--

DROP TABLE IF EXISTS `lld_override`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override` (
  `lld_overrideid` bigint unsigned NOT NULL,
  `itemid` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `step` int NOT NULL DEFAULT '0',
  `evaltype` int NOT NULL DEFAULT '0',
  `formula` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `stop` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`lld_overrideid`),
  UNIQUE KEY `lld_override_1` (`itemid`,`name`),
  CONSTRAINT `c_lld_override_1` FOREIGN KEY (`itemid`) REFERENCES `items` (`itemid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override`
--

LOCK TABLES `lld_override` WRITE;
/*!40000 ALTER TABLE `lld_override` DISABLE KEYS */;
INSERT INTO `lld_override` VALUES (4383,43134,'aggregated status',1,0,'',0),(4384,43134,'checks',2,0,'',0),(4385,30961,'trigger',1,0,'',0),(4386,30193,'Discard HTTP status codes',1,0,'',0),(4387,30194,'Discard HTTP status codes',1,0,'',0),(4388,30195,'Discard HTTP status codes',1,0,'',0),(4389,30236,'Discard HTTP status codes',1,0,'',0),(4390,30237,'Discard HTTP status codes',1,0,'',0),(4391,30238,'Discard HTTP status codes',1,0,'',0),(4392,39854,'bucket item',1,0,'',0),(4393,39854,'total item',2,0,'',0),(4394,39859,'bucket item',1,0,'',0),(4395,39859,'total item',2,0,'',0),(4396,39889,'bucket item',1,0,'',0),(4397,39889,'total item',2,0,'',0),(4398,39920,'bucket item',1,0,'',0),(4399,39920,'total item',2,0,'',0),(4400,44733,'Endpoints host',1,0,'',0),(4401,40000,'bucket item',1,0,'',0),(4402,40000,'total item',2,0,'',0),(4403,40001,'bucket item',1,0,'',0),(4404,40001,'total item',2,0,'',0),(4405,40002,'bucket item',1,0,'',0),(4406,40002,'total item',2,0,'',0),(4407,40030,'sum items',1,0,'',0),(4408,44762,'sum items',1,0,'',0),(4409,33521,'trigger disabled non main channels',1,0,'',0),(4410,44200,'Flexible server',1,0,'',0),(4411,44200,'Single server',2,0,'',0),(4412,44293,'Flexible server',1,0,'',0),(4413,44293,'Single server',2,0,'',0),(4414,44585,'Server',2,0,'',0),(4415,44585,'Serverless',1,0,'',0),(4416,44818,'MongoDB',1,0,'',0),(4417,45034,'MSSQL replica',1,0,'',0),(4418,45035,'MySQL replica',1,0,'',0),(4419,45036,'PostgreSQL replica',1,0,'',0),(4420,33810,'Arbiter metrics',2,0,'',0),(4421,33810,'Primary metrics',1,0,'',0),(4422,34346,'Too many missed regions trigger',1,0,'',0),(4423,34346,'Unresponsive peers trigger',2,0,'',0),(4424,34403,'Failed GC-related operations trigger',1,0,'',0),(4425,34443,'Too many unreachable messages trigger',1,0,'',0),(4426,28306,'trigger THRESHOLD_LO_WARN',1,0,'',0),(4427,28306,'trigger THRESHOLD_LO_CRIT',2,0,'',0),(4428,28306,'trigger THRESHOLD_HI_WARN',3,0,'',0),(4429,28306,'trigger THRESHOLD_HI_CRIT',4,0,'',0),(4430,28307,'trigger THRESHOLD_LO_WARN',1,0,'',0),(4431,28307,'trigger THRESHOLD_LO_CRIT',2,0,'',0),(4432,28307,'trigger THRESHOLD_HI_WARN',3,0,'',0),(4433,28307,'trigger THRESHOLD_HI_CRIT',4,0,'',0),(4434,33182,'trigger THRESHOLD_LO_WARN',1,0,'',0),(4435,33182,'trigger THRESHOLD_LO_CRIT',2,0,'',0),(4436,33182,'trigger THRESHOLD_HI_WARN',3,0,'',0),(4437,33182,'trigger THRESHOLD_HI_CRIT',4,0,'',0),(4438,35366,'Don\'t create triggers for matching interface',1,0,'',0),(4439,35432,'Skip trigger for defined filesystems',1,0,'',0),(4440,35542,'Don\'t create triggers for matching interface',1,0,'',0),(4441,35543,'Don\'t create triggers for matching interface',1,0,'',0),(4442,35575,'Don\'t create triggers for matching interface',1,0,'',0),(4443,35619,'Don\'t create triggers for matching interface',1,0,'',0),(4444,35653,'Don\'t create triggers for matching interface',1,0,'',0),(4445,35654,'Don\'t create triggers for matching interface',1,0,'',0),(4446,35720,'Don\'t create triggers for matching interface',1,0,'',0),(4447,35721,'Don\'t create triggers for matching interface',1,0,'',0),(4448,35787,'Don\'t create triggers for matching interface',1,0,'',0),(4449,35788,'Trigger disabled',1,0,'',0),(4450,35788,'Trigger enabled',2,0,'',0),(4451,35820,'Don\'t create triggers for matching interface',1,0,'',0),(4452,35859,'Don\'t create triggers for matching interface',1,0,'',0),(4453,35903,'Don\'t create triggers for matching interface',1,0,'',0),(4454,35947,'Don\'t create triggers for matching interface',1,0,'',0),(4455,35991,'Don\'t create triggers for matching interface',1,0,'',0),(4456,36036,'Don\'t create triggers for matching interface',1,0,'',0),(4457,36081,'Don\'t create triggers for matching interface',1,0,'',0),(4458,36126,'Don\'t create triggers for matching interface',1,0,'',0),(4459,22947,'Skip metadata collection for dynamic FS',1,0,'',0),(4460,22907,'Skip metadata collection for dynamic FS',1,0,'',0),(4461,22987,'Skip metadata collection for dynamic FS',1,0,'',0),(4462,42273,'Skip metadata collection for dynamic FS',1,0,'',0),(4463,42276,'Skip metadata collection for dynamic FS',1,0,'',0),(4464,42362,'Skip metadata collection for dynamic FS',1,0,'',0),(4465,23067,'Exclude dmg',1,1,'',0),(4466,23067,'Skip metadata collection for dynamic FS',2,0,'',0),(4467,22867,'Skip metadata collection for dynamic FS',1,0,'',0),(4468,23027,'Skip metadata collection for dynamic FS',1,0,'',0),(4469,34478,'Temp',1,0,'',0),(4470,34479,'Temp',1,0,'',0),(4471,34526,'Temp',1,0,'',0),(4472,34527,'Temp',1,0,'',0),(4473,34574,'Temp',1,0,'',0),(4474,34575,'Temp',1,0,'',0),(4475,34622,'Temp',1,0,'',0),(4476,34623,'Temp',1,0,'',0),(4477,34670,'Temp',1,1,'',0),(4478,34671,'Temp',1,0,'',0),(4479,35043,'Temp',1,0,'',0),(4480,35044,'Temp',1,0,'',0),(4481,34766,'Temp',1,0,'',0),(4482,34767,'Temp',1,0,'',0),(4483,34209,'Temp',1,0,'',0),(4484,34210,'Temp',1,0,'',0),(4485,34820,'Temp',1,0,'',0),(4486,34821,'Temp',1,0,'',0),(4487,34868,'Temp',1,0,'',0),(4488,34869,'Temp',1,0,'',0),(4489,34916,'Temp',1,0,'',0),(4490,34917,'Temp',1,0,'',0),(4491,43185,'SSD life left',1,0,'',0),(4492,43292,'SSD life left',1,0,'',0),(4493,33354,'Do not discover aggregate metrics',1,0,'',0),(4494,30687,'trigger SENSOR_HI_CRIT',5,0,'',0),(4495,30687,'trigger SENSOR_HI_DISAST',6,0,'',0),(4496,30687,'trigger SENSOR_HI_WARN',4,0,'',0),(4497,30687,'trigger SENSOR_LO_CRIT',2,0,'',0),(4498,30687,'trigger SENSOR_LO_DISAST',3,0,'',0),(4499,30687,'trigger SENSOR_LO_WARN',1,0,'',0),(4500,44676,'Bad_Block_Rate',9,0,'',0),(4501,44676,'Not NVMe',2,0,'',0),(4502,44676,'Power_Cycle_Count',6,0,'',0),(4503,44676,'Program_Fail_Count_Chip',10,0,'',0),(4504,44676,'Raw_Read_Error_Rate',3,0,'',0),(4505,44676,'Reallocated_Sector_Ct',11,0,'',0),(4506,44676,'Reported_Uncorrect',7,0,'',0),(4507,44676,'Seek_Error_Rate',8,0,'',0),(4508,44676,'Self-test',1,0,'',0),(4509,44676,'Spin_Up_Time',4,0,'',0),(4510,44676,'Start_Stop_Count',5,0,'',0),(4511,44697,'Bad_Block_Rate',9,0,'',0),(4512,44697,'Not NVMe',2,0,'',0),(4513,44697,'Power_Cycle_Count',6,0,'',0),(4514,44697,'Program_Fail_Count_Chip',10,0,'',0),(4515,44697,'Raw_Read_Error_Rate',3,0,'',0),(4516,44697,'Reallocated_Sector_Ct',11,0,'',0),(4517,44697,'Reported_Uncorrect',7,0,'',0),(4518,44697,'Seek_Error_Rate',8,0,'',0),(4519,44697,'Self-test',1,0,'',0),(4520,44697,'Spin_Up_Time',4,0,'',0),(4521,44697,'Start_Stop_Count',5,0,'',0),(4522,45595,'Serverless',1,0,'',0),(4523,45595,'Use EC2 Infrastructure',2,0,'',0),(4524,46167,'System services',1,0,'',0),(4525,46323,'Predicted media life left',1,0,'',0),(4526,31123,'Log backup',1,0,'',0),(4527,46503,'Application Load Balancers',1,0,'',0),(4528,46595,'Log backup',1,0,'',0),(4529,46503,'Network Load Balancers',2,0,'',0),(4530,29430,'Skip metadata collection for dynamic FS',1,0,'',0),(4531,47433,'Trigger priority red',1,0,'',0),(4532,47433,'Trigger priority yellow',2,0,'',0),(4533,47433,'Trigger priority green',3,0,'',0),(4534,31656,'Disable IO perfCounter',1,0,'',0),(4535,32934,'Disable IO perfCounter',1,0,'',0),(4536,32934,'Disable Multipath perfCounter',2,0,'',0),(4537,47447,'Trigger priority red',1,0,'',0),(4538,47447,'Trigger priority yellow',2,0,'',0),(4539,47447,'Trigger priority green',3,0,'',0),(4540,32955,'Disable IO perfCounter',1,0,'',0),(4541,44057,'Tag proxy-group if exists',1,0,'',0),(4542,44058,'Tag proxy-group if exists',1,0,'',0),(4543,44082,'Tag proxy-group if exists',1,0,'',0),(4544,48513,'Do not create tentative state trigger for Active-Passive mode',1,0,'',0),(4545,48515,'Do not create speed item and trigger if not supported',1,0,'',0),(4546,48516,'Add zone tag',1,0,'',0),(4547,49438,'Tag proxy-group if exists',1,0,'',0),(4548,49440,'Tag proxy-group if exists',1,0,'',0),(4549,44585,'DTU-based',3,0,'',0),(4550,49583,'Skip metadata collection for dynamic FS',1,0,'',0),(4551,49686,'Skip metadata collection for dynamic FS',1,0,'',0),(4552,49789,'Skip metadata collection for dynamic FS',1,0,'',0),(4553,49892,'Skip metadata collection for dynamic FS',1,0,'',0),(4554,49995,'Skip metadata collection for dynamic FS',1,0,'',0),(4555,50098,'Skip metadata collection for dynamic FS',1,0,'',0),(4556,50201,'Skip metadata collection for dynamic FS',1,0,'',0);
/*!40000 ALTER TABLE `lld_override` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:15

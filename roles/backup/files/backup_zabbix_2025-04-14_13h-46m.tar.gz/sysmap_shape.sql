-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sysmap_shape`
--

DROP TABLE IF EXISTS `sysmap_shape`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sysmap_shape` (
  `sysmap_shapeid` bigint unsigned NOT NULL,
  `sysmapid` bigint unsigned NOT NULL,
  `type` int NOT NULL DEFAULT '0',
  `x` int NOT NULL DEFAULT '0',
  `y` int NOT NULL DEFAULT '0',
  `width` int NOT NULL DEFAULT '200',
  `height` int NOT NULL DEFAULT '200',
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `font` int NOT NULL DEFAULT '9',
  `font_size` int NOT NULL DEFAULT '11',
  `font_color` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '000000',
  `text_halign` int NOT NULL DEFAULT '0',
  `text_valign` int NOT NULL DEFAULT '0',
  `border_type` int NOT NULL DEFAULT '0',
  `border_width` int NOT NULL DEFAULT '1',
  `border_color` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '000000',
  `background_color` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `zindex` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`sysmap_shapeid`),
  KEY `sysmap_shape_1` (`sysmapid`),
  CONSTRAINT `c_sysmap_shape_1` FOREIGN KEY (`sysmapid`) REFERENCES `sysmaps` (`sysmapid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysmap_shape`
--

LOCK TABLES `sysmap_shape` WRITE;
/*!40000 ALTER TABLE `sysmap_shape` DISABLE KEYS */;
INSERT INTO `sysmap_shape` VALUES (1,2,0,1,1,1125,810,'',9,11,'000000',0,0,1,2,'0080FF','',0),(2,2,0,520,15,552,50,'Otus Professional project landscape',9,30,'000000',0,0,1,2,'000000','',1),(3,2,0,900,675,100,40,'Monitoring (Zabbix+Grafana)',9,11,'000000',0,0,0,2,'000000','',2),(4,2,0,40,230,156,50,'https://init6.ru/\r\nhttps://zabbix.init6.ru/zabbix/\r\nhttps://grafana.init6.ru/\r\nhttps://elk.init6.ru/',9,11,'000000',1,0,0,1,'00BFFF','FFFFFF',3),(5,2,0,10,90,300,130,'root@nginx:~# iptables -nvL\r\nChain INPUT (policy DROP 40133 packets, 5860K bytes)\r\ntarget   prot opt in   out   source         destination\r\nACCEPT   0    --  lo   *     0.0.0.0/0      0.0.0.0/0            \r\nDROP     0    --  *    *     0.0.0.0/0      0.0.0.0/0   state INVALID\r\nACCEPT   0    --  *    *     0.0.0.0/0      0.0.0.0/0   state RELATED,ESTABLISHED\r\nACCEPT   1    --  *    *     0.0.0.0/0      0.0.0.0/0            \r\nACCEPT   6    --  *    *     0.0.0.0/0      0.0.0.0/0   multiport dports 80,443\r\nACCEPT   6    --  *    *     10.68.0.0/21   0.0.0.0/0   tcp dpt:10050\r\nACCEPT   6    --  *    *     10.68.0.0/21   0.0.0.0/0   tcp dpt:22',9,10,'000000',1,0,0,2,'000000','',4);
/*!40000 ALTER TABLE `sysmap_shape` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:19

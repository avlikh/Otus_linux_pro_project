-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events` (
  `eventid` bigint unsigned NOT NULL,
  `source` int NOT NULL DEFAULT '0',
  `object` int NOT NULL DEFAULT '0',
  `objectid` bigint unsigned NOT NULL DEFAULT '0',
  `clock` int NOT NULL DEFAULT '0',
  `value` int NOT NULL DEFAULT '0',
  `acknowledged` int NOT NULL DEFAULT '0',
  `ns` int NOT NULL DEFAULT '0',
  `name` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `severity` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`eventid`),
  KEY `events_1` (`source`,`object`,`objectid`,`clock`),
  KEY `events_2` (`source`,`object`,`clock`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (23,0,0,22391,1743531986,1,0,492396216,'Linux: Zabbix agent is not available (for 3m)',3),(24,0,0,22391,1743575220,0,0,55895499,'Linux: Zabbix agent is not available (for 3m)',0),(25,0,0,22391,1743575246,1,0,951884774,'Linux: Zabbix agent is not available (for 3m)',3),(42,0,0,22391,1743579086,0,0,493618118,'Linux: Zabbix agent is not available (for 3m)',0),(49,0,0,24735,1743607458,1,0,250213935,'Linux: Zabbix agent is not available (for 3m)',3),(60,0,0,24735,1743607818,0,0,608907116,'Linux: Zabbix agent is not available (for 3m)',0),(183,0,0,24735,1743688278,1,0,549385621,'Linux: Zabbix agent is not available (for 3m)',3),(185,0,0,24731,1743688502,1,0,337847459,'Linux: NGINX has been restarted (uptime < 10m)',2),(187,0,0,24735,1743688518,0,0,883471862,'Linux: Zabbix agent is not available (for 3m)',0),(188,0,0,24731,1743689081,0,0,275818132,'Linux: NGINX has been restarted (uptime < 10m)',0),(189,0,0,22388,1743690150,1,0,719456150,'Linux: Zabbix server has been restarted (uptime < 10m)',2),(204,0,0,22388,1743690720,0,0,717549933,'Linux: Zabbix server has been restarted (uptime < 10m)',0),(211,0,0,24771,1743704604,1,0,724614560,'Linux: Apache1 has been restarted (uptime < 10m)',2),(212,0,0,24811,1743704625,1,0,822417105,'Linux: Apache2 has been restarted (uptime < 10m)',2),(213,0,0,24771,1743705204,0,0,725064452,'Linux: Apache1 has been restarted (uptime < 10m)',0),(214,0,0,24811,1743705217,0,0,722509131,'Linux: Apache2 has been restarted (uptime < 10m)',0),(215,0,0,24775,1743780421,1,0,867450766,'Linux: Zabbix agent is not available (for 3m)',3),(216,0,0,24735,1743780438,1,0,885574965,'Linux: Zabbix agent is not available (for 3m)',3),(217,0,0,24815,1743780464,1,0,910688909,'Linux: Zabbix agent is not available (for 3m)',3),(220,0,0,24731,1743781126,1,0,816528365,'Linux: NGINX has been restarted (uptime < 10m)',2),(223,0,0,24735,1743781158,0,0,444551422,'Linux: Zabbix agent is not available (for 3m)',0),(224,0,0,24729,1743781566,1,0,756796493,'Linux: Number of installed packages has been changed',2),(225,0,0,24731,1743781601,0,0,719866836,'Linux: NGINX has been restarted (uptime < 10m)',0),(230,0,0,24775,1743781801,0,0,146981458,'Linux: Zabbix agent is not available (for 3m)',0),(231,0,0,24815,1743781844,0,0,195952455,'Linux: Zabbix agent is not available (for 3m)',0),(240,0,0,24729,1743828366,0,0,747310473,'Linux: Number of installed packages has been changed',0),(249,0,0,22388,1744134120,1,0,497322775,'Linux: Zabbix server has been restarted (uptime < 10m)',2),(258,0,0,23162,1744134235,1,0,526451091,'Linux: Number of installed packages has been changed',2),(261,0,0,22388,1744134300,0,0,498240580,'Linux: Zabbix server has been restarted (uptime < 10m)',0),(270,0,0,23162,1744134410,0,0,712750045,'Linux: Number of installed packages has been changed',0),(275,0,0,24729,1744188366,1,0,518958217,'Linux: Number of installed packages has been changed',2),(288,0,0,22395,1744270929,1,0,89845917,'Linux: Load average is too high (per CPU load over 1.5 for 5m)',3),(295,0,0,22395,1744270989,0,0,86820860,'Linux: Load average is too high (per CPU load over 1.5 for 5m)',0),(300,0,0,24845,1744271043,1,0,95822250,'Linux: High CPU utilization (over 90% for 5m)',2),(304,0,0,24845,1744271103,0,0,93508234,'Linux: High CPU utilization (over 90% for 5m)',0),(316,0,0,24892,1744271585,1,0,96346280,'Linux: /etc/passwd has been changed',1),(317,0,0,24932,1744271688,1,0,99002947,'Linux: /etc/passwd has been changed',1),(318,0,0,24892,1744275185,0,0,93686591,'Linux: /etc/passwd has been changed',0),(319,0,0,24932,1744275288,0,0,94940029,'Linux: /etc/passwd has been changed',0),(320,0,0,24855,1744281567,1,0,316491231,'Linux: Zabbix agent is not available (for 3m)',3),(321,0,0,24851,1744283229,1,0,174435315,'Linux: ELK has been restarted (uptime < 10m)',2),(324,0,0,24855,1744283247,0,0,253062695,'Linux: Zabbix agent is not available (for 3m)',0),(325,0,0,24851,1744283390,0,0,94960137,'Linux: ELK has been restarted (uptime < 10m)',0),(326,0,0,24855,1744284387,1,0,507990753,'Linux: Zabbix agent is not available (for 3m)',3),(329,0,0,24851,1744284442,1,0,159059104,'Linux: ELK has been restarted (uptime < 10m)',2),(332,0,0,24855,1744284447,0,0,577515212,'Linux: Zabbix agent is not available (for 3m)',0),(333,0,0,24845,1744284543,1,0,95283392,'Linux: High CPU utilization (over 90% for 5m)',2),(334,0,0,24845,1744284603,0,0,101043990,'Linux: High CPU utilization (over 90% for 5m)',0),(337,0,0,24851,1744285760,0,0,92471440,'Linux: ELK has been restarted (uptime < 10m)',0),(338,0,0,24855,1744290093,1,0,843003920,'Linux: Zabbix agent is not available (for 3m)',3),(344,0,0,24851,1744291150,1,0,209226313,'Linux: ELK has been restarted (uptime < 10m)',2),(350,0,0,24855,1744291167,0,0,136972749,'Linux: Zabbix agent is not available (for 3m)',0),(351,0,0,24851,1744291670,0,0,99192868,'Linux: ELK has been restarted (uptime < 10m)',0),(352,0,0,24851,1744296731,1,0,163590130,'Linux: ELK has been restarted (uptime < 10m)',2),(353,0,0,24851,1744297310,0,0,95931562,'Linux: ELK has been restarted (uptime < 10m)',0),(354,0,0,24851,1744301449,1,0,179771697,'Linux: ELK has been restarted (uptime < 10m)',2),(355,0,0,24851,1744302050,0,0,93500911,'Linux: ELK has been restarted (uptime < 10m)',0),(356,0,0,24851,1744305870,1,0,204883479,'Linux: ELK has been restarted (uptime < 10m)',2),(359,0,0,24731,1744306751,1,0,423797861,'Linux: NGINX has been restarted (uptime < 10m)',2),(360,0,0,24931,1744306756,1,0,419315696,'Linux: Mysqlrep has been restarted (uptime < 10m)',2),(361,0,0,24771,1744306764,1,0,423076186,'Linux: Apache1 has been restarted (uptime < 10m)',2),(362,0,0,24855,1744306767,1,0,471853577,'Linux: Zabbix agent is not available (for 3m)',3),(363,0,0,22388,1744306770,1,0,415794953,'Linux: Zabbix server has been restarted (uptime < 10m)',2),(366,0,0,24891,1744306773,1,0,427247606,'Linux: Mysqlsrs has been restarted (uptime < 10m)',2),(370,0,0,24811,1744306790,1,0,497229448,'Linux: Apache2 has been restarted (uptime < 10m)',2),(376,0,0,24845,1744306814,1,0,447772520,'Linux: High CPU utilization (over 90% for 5m)',2),(379,0,0,24855,1744306827,0,0,549405807,'Linux: Zabbix agent is not available (for 3m)',0),(380,0,0,24845,1744306863,0,0,416697000,'Linux: High CPU utilization (over 90% for 5m)',0),(395,0,0,24729,1744307166,0,0,454439147,'Linux: Number of installed packages has been changed',0),(396,0,0,24731,1744307321,0,0,415082669,'Linux: NGINX has been restarted (uptime < 10m)',0),(397,0,0,24771,1744307334,0,0,415759619,'Linux: Apache1 has been restarted (uptime < 10m)',0),(398,0,0,22388,1744307340,0,0,414911864,'Linux: Zabbix server has been restarted (uptime < 10m)',0),(399,0,0,24891,1744307343,0,0,416557300,'Linux: Mysqlsrs has been restarted (uptime < 10m)',0),(400,0,0,24931,1744307356,0,0,415466326,'Linux: Mysqlrep has been restarted (uptime < 10m)',0),(401,0,0,24851,1744307360,0,0,416715279,'Linux: ELK has been restarted (uptime < 10m)',0),(402,0,0,24811,1744307377,0,0,415194813,'Linux: Apache2 has been restarted (uptime < 10m)',0),(403,0,0,24851,1744309023,1,0,482048467,'Linux: ELK has been restarted (uptime < 10m)',2),(404,0,0,24855,1744309947,1,0,560615662,'Linux: Zabbix agent is not available (for 3m)',3),(411,0,0,24855,1744310187,0,0,813619045,'Linux: Zabbix agent is not available (for 3m)',0),(412,0,0,24851,1744310660,0,0,417897936,'Linux: ELK has been restarted (uptime < 10m)',0),(413,0,0,24855,1744312707,1,0,599491521,'Linux: Zabbix agent is not available (for 3m)',3),(415,0,0,24851,1744312749,1,0,483942659,'Linux: ELK has been restarted (uptime < 10m)',2),(417,0,0,24855,1744312767,0,0,669759344,'Linux: Zabbix agent is not available (for 3m)',0),(418,0,0,24845,1744312803,1,0,419133020,'Linux: High CPU utilization (over 90% for 5m)',2),(419,0,0,24845,1744312863,0,0,421076876,'Linux: High CPU utilization (over 90% for 5m)',0),(420,0,0,24851,1744313510,0,0,417528060,'Linux: ELK has been restarted (uptime < 10m)',0),(421,0,0,22395,1744421529,1,0,490299055,'Linux: Load average is too high (per CPU load over 1.5 for 5m)',3),(422,0,0,22395,1744421589,0,0,485407541,'Linux: Load average is too high (per CPU load over 1.5 for 5m)',0),(437,0,0,23162,1744422235,1,0,529348653,'Linux: Number of installed packages has been changed',2),(438,0,0,24729,1744422366,1,0,505332448,'Linux: Number of installed packages has been changed',2),(439,0,0,23162,1744440430,0,0,553118693,'Linux: Number of installed packages has been changed',0),(440,0,0,24729,1744440430,0,0,607489580,'Linux: Number of installed packages has been changed',0),(458,0,0,22393,1744466458,1,0,480632562,'Linux: High swap space usage (less than 50% free)',2),(459,0,0,22393,1744467356,0,0,480948912,'Linux: High swap space usage (less than 50% free)',0),(461,0,0,22393,1744468196,1,0,484722561,'Linux: High swap space usage (less than 50% free)',2),(462,0,0,22388,1744468350,1,0,163818608,'Linux: Zabbix server has been restarted (uptime < 10m)',2),(463,0,0,22393,1744468376,0,0,162929347,'Linux: High swap space usage (less than 50% free)',0),(464,0,0,22388,1744468380,0,0,154768425,'Linux: Zabbix server has been restarted (uptime < 10m)',0),(465,0,0,22388,1744468380,1,0,162638007,'Linux: Zabbix server has been restarted (uptime < 10m)',2),(482,0,0,22388,1744468950,0,0,161531255,'Linux: Zabbix server has been restarted (uptime < 10m)',0);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:03

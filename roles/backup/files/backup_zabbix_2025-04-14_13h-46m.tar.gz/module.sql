-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `module`
--

DROP TABLE IF EXISTS `module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `module` (
  `moduleid` bigint unsigned NOT NULL,
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `relative_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `status` int NOT NULL DEFAULT '0',
  `config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`moduleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `module`
--

LOCK TABLES `module` WRITE;
/*!40000 ALTER TABLE `module` DISABLE KEYS */;
INSERT INTO `module` VALUES (1,'actionlog','widgets/actionlog',1,'[]'),(2,'clock','widgets/clock',1,'[]'),(3,'topitems','widgets/topitems',1,'[]'),(4,'discovery','widgets/discovery',1,'[]'),(5,'favgraphs','widgets/favgraphs',1,'[]'),(6,'favmaps','widgets/favmaps',1,'[]'),(7,'geomap','widgets/geomap',1,'[]'),(8,'graph','widgets/graph',1,'[]'),(9,'graphprototype','widgets/graphprototype',1,'[]'),(10,'hostavail','widgets/hostavail',1,'[]'),(11,'item','widgets/item',1,'[]'),(12,'map','widgets/map',1,'[]'),(13,'navtree','widgets/navtree',1,'[]'),(14,'itemhistory','widgets/itemhistory',1,'[]'),(15,'problemhosts','widgets/problemhosts',1,'[]'),(16,'problems','widgets/problems',1,'[]'),(17,'problemsbysv','widgets/problemsbysv',1,'[]'),(18,'slareport','widgets/slareport',1,'[]'),(19,'svggraph','widgets/svggraph',1,'[]'),(20,'systeminfo','widgets/systeminfo',1,'[]'),(21,'tophosts','widgets/tophosts',1,'[]'),(22,'trigover','widgets/trigover',1,'[]'),(23,'url','widgets/url',1,'[]'),(24,'web','widgets/web',1,'[]'),(25,'gauge','widgets/gauge',1,'[]'),(26,'toptriggers','widgets/toptriggers',1,'[]'),(27,'piechart','widgets/piechart',1,'[]'),(28,'honeycomb','widgets/honeycomb',1,'[]'),(29,'hostnavigator','widgets/hostnavigator',1,'[]'),(30,'itemnavigator','widgets/itemnavigator',1,'[]'),(31,'hostcard','widgets/hostcard',1,'[]');
/*!40000 ALTER TABLE `module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:17

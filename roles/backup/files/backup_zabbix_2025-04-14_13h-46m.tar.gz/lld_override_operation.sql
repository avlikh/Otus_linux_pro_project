-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lld_override_operation`
--

DROP TABLE IF EXISTS `lld_override_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lld_override_operation` (
  `lld_override_operationid` bigint unsigned NOT NULL,
  `lld_overrideid` bigint unsigned NOT NULL,
  `operationobject` int NOT NULL DEFAULT '0',
  `operator` int NOT NULL DEFAULT '0',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`lld_override_operationid`),
  KEY `lld_override_operation_1` (`lld_overrideid`),
  CONSTRAINT `c_lld_override_operation_1` FOREIGN KEY (`lld_overrideid`) REFERENCES `lld_override` (`lld_overrideid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lld_override_operation`
--

LOCK TABLES `lld_override_operation` WRITE;
/*!40000 ALTER TABLE `lld_override_operation` DISABLE KEYS */;
INSERT INTO `lld_override_operation` VALUES (4539,4383,0,2,'Aggregated status'),(4540,4383,0,2,'State'),(4541,4384,0,2,'Check'),(4542,4385,1,2,'Too many failed gRPC requests'),(4543,4386,0,2,'Number of responses with codes'),(4544,4387,0,2,'Number of responses with codes'),(4545,4388,0,2,'Number of responses with codes'),(4546,4389,0,2,'Number of responses with codes'),(4547,4390,0,2,'Number of responses with codes'),(4548,4391,0,2,'Number of responses with codes'),(4549,4392,0,2,'bucket'),(4550,4393,0,3,'bucket'),(4551,4394,0,2,'bucket'),(4552,4395,0,3,'bucket'),(4553,4396,0,2,'bucket'),(4554,4397,0,3,'bucket'),(4555,4398,0,2,'bucket'),(4556,4399,0,3,'bucket'),(4557,4400,3,8,''),(4558,4401,0,2,'bucket'),(4559,4402,0,3,'bucket'),(4560,4403,0,2,'bucket'),(4561,4404,0,3,'bucket'),(4562,4405,0,2,'bucket'),(4563,4406,0,3,'bucket'),(4564,4407,0,8,'status phase.*sum'),(4565,4407,0,9,'status phase.*sum'),(4566,4407,1,8,'.*'),(4567,4408,0,8,'status phase.*sum'),(4568,4408,0,9,'status phase.*sum'),(4569,4408,1,8,'.*'),(4570,4409,1,2,'Invalid video stream resolution parameters'),(4571,4410,3,8,''),(4572,4411,3,8,''),(4573,4412,3,8,''),(4574,4413,3,8,''),(4575,4414,3,8,''),(4576,4415,3,8,''),(4577,4416,3,8,''),(4578,4417,3,8,''),(4579,4418,3,8,''),(4580,4419,3,8,''),(4581,4420,0,2,'Replication lag'),(4582,4421,0,2,'Number of replicas'),(4583,4421,0,2,'Unhealthy replicas'),(4584,4421,0,2,'Number of unhealthy replicas'),(4585,4421,0,2,'Replication lag'),(4586,4422,1,2,'Too many missed regions'),(4587,4423,1,2,'There are unresponsive peers'),(4588,4424,1,2,'Too many failed GC-related operations'),(4589,4425,1,2,'Too many failure messages'),(4590,4426,1,8,'Temperature is below the warning threshold'),(4591,4427,1,8,'Temperature is below the critical threshold'),(4592,4428,1,8,'Temperature is above the warning threshold'),(4593,4429,1,8,'Temperature is above the critical threshold'),(4594,4430,1,8,'Fan speed is below the warning threshold'),(4595,4431,1,8,'Fan speed is below the critical threshold'),(4596,4432,1,8,'Fan speed is above the warning threshold'),(4597,4433,1,8,'Fan speed is above the critical threshold'),(4598,4434,1,8,'Voltage is below the warning threshold'),(4599,4435,1,8,'Voltage is below the critical threshold'),(4600,4436,1,8,'Voltage is above the warning threshold'),(4601,4437,1,8,'Voltage is above the critical threshold'),(4602,4438,1,8,'.*'),(4603,4439,1,8,'^F5 BIG-IP: Low free space in file system'),(4604,4440,1,8,'.*'),(4605,4441,1,8,'.*'),(4606,4442,1,8,'.*'),(4607,4443,1,8,'.*'),(4608,4444,1,8,'.*'),(4609,4445,1,8,'.*'),(4610,4446,1,8,'.*'),(4611,4447,1,8,'.*'),(4612,4448,1,8,'.*'),(4613,4449,1,8,'.*'),(4614,4450,1,8,'.*'),(4615,4451,1,8,'.*'),(4616,4452,1,8,'.*'),(4617,4453,1,8,'.*'),(4618,4454,1,8,'.*'),(4619,4455,1,8,'.*'),(4620,4456,1,8,'.*'),(4621,4457,1,8,'.*'),(4622,4458,1,8,'.*'),(4629,4465,0,8,'.+'),(4633,4469,0,2,'Humidity'),(4634,4470,0,2,'Humidity'),(4635,4471,0,2,'Humidity'),(4636,4472,0,2,'Humidity'),(4637,4473,0,2,'Humidity'),(4638,4474,0,2,'Humidity'),(4639,4475,0,2,'Humidity'),(4640,4476,0,2,'Humidity'),(4641,4477,0,2,'Humidity'),(4642,4478,0,2,'Humidity'),(4643,4479,0,2,'Humidity'),(4644,4480,0,2,'Humidity'),(4645,4481,0,2,'Humidity'),(4646,4482,0,2,'Humidity'),(4647,4483,0,2,'Humidity'),(4648,4484,0,2,'Humidity'),(4649,4485,0,2,'Humidity'),(4650,4486,0,2,'Humidity'),(4651,4487,0,2,'Humidity'),(4652,4488,0,2,'Humidity'),(4653,4489,0,2,'Humidity'),(4654,4490,0,2,'Humidity'),(4655,4491,0,8,'SSD life left'),(4656,4492,0,8,'SSD life left'),(4657,4493,0,2,'Saved'),(4658,4494,1,2,'{#SENSOR_HI_CRIT}'),(4659,4495,1,2,'{#SENSOR_HI_DISAST}'),(4660,4496,1,2,'{#SENSOR_HI_WARN}'),(4661,4497,1,2,'{#SENSOR_LO_CRIT}'),(4662,4498,1,2,'{#SENSOR_LO_DISAST}'),(4663,4499,1,2,'{#SENSOR_LO_WARN}'),(4664,4500,0,8,'Bad_Block_Rate'),(4665,4501,0,8,'Media|Percentage|Critical'),(4666,4502,0,8,'Power_Cycle_Count'),(4667,4503,0,8,'Program_Fail_Count_Chip'),(4668,4504,0,8,'Raw_Read_Error_Rate'),(4669,4505,0,8,'Reallocated_Sector_Ct'),(4670,4506,0,8,'Reported_Uncorrect'),(4671,4507,0,8,'Seek_Error_Rate'),(4672,4508,0,2,'Self-test'),(4673,4509,0,8,'Spin_Up_Time'),(4674,4510,0,8,'Start_Stop_Count'),(4675,4511,0,8,'Bad_Block_Rate'),(4676,4512,0,8,'Media|Percentage|Critical'),(4677,4513,0,8,'Power_Cycle_Count'),(4678,4514,0,8,'Program_Fail_Count_Chip'),(4679,4515,0,8,'Raw_Read_Error_Rate'),(4680,4516,0,8,'Reallocated_Sector_Ct'),(4681,4517,0,8,'Reported_Uncorrect'),(4682,4518,0,8,'Seek_Error_Rate'),(4683,4519,0,2,'Self-test'),(4684,4520,0,8,'Spin_Up_Time'),(4685,4521,0,8,'Start_Stop_Count'),(4686,4522,3,8,''),(4687,4523,3,8,''),(4688,4524,0,2,': Expiration date'),(4689,4524,0,2,': Last attempt to update'),(4690,4524,0,2,': Last update time'),(4691,4524,0,2,': Service version'),(4692,4524,0,2,': Update method'),(4693,4524,0,2,': Update result'),(4694,4525,0,8,'Predicted media life left'),(4695,4526,1,2,'Log backup is old'),(4696,4527,3,8,''),(4697,4528,1,2,'Log backup is old'),(4698,4529,3,8,''),(4699,4459,0,2,'Inodes'),(4700,4460,0,2,'Inodes'),(4701,4461,0,2,'Inodes'),(4702,4462,0,2,'Inodes'),(4703,4463,0,2,'Inodes'),(4704,4464,0,2,'Inodes'),(4705,4530,0,2,'Inodes'),(4706,4466,0,2,'Inodes'),(4707,4467,0,2,'Inodes'),(4708,4468,0,2,'Inodes'),(4709,4531,1,8,'VMware: *'),(4710,4532,1,8,'VMware: *'),(4711,4533,1,8,'VMware: *'),(4712,4534,0,2,'Average'),(4713,4535,0,2,'Average'),(4714,4536,0,2,'Multipath count for datastore'),(4715,4537,1,8,'VMware: *'),(4716,4538,1,8,'VMware: *'),(4717,4539,1,8,'VMware: *'),(4718,4540,0,2,'Average'),(4719,4541,0,8,''),(4720,4542,0,8,''),(4721,4543,0,8,''),(4722,4544,1,0,'HA is in \"tentative\" state'),(4723,4545,0,8,'Speed'),(4724,4545,1,8,'High bandwidth usage'),(4725,4546,0,8,'.+'),(4726,4547,0,8,''),(4727,4548,0,8,''),(4728,4549,3,8,''),(4729,4550,0,2,'Inodes'),(4730,4551,0,2,'Inodes'),(4731,4552,0,2,'Inodes'),(4732,4553,0,2,'Inodes'),(4733,4554,0,2,'Inodes'),(4734,4555,0,2,'Inodes'),(4735,4556,0,2,'Inodes');
/*!40000 ALTER TABLE `lld_override_operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:16

-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `host_discovery`
--

DROP TABLE IF EXISTS `host_discovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `host_discovery` (
  `hostid` bigint unsigned NOT NULL,
  `parent_hostid` bigint unsigned DEFAULT NULL,
  `parent_itemid` bigint unsigned DEFAULT NULL,
  `host` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `lastcheck` int NOT NULL DEFAULT '0',
  `ts_delete` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `disable_source` int NOT NULL DEFAULT '0',
  `ts_disable` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`hostid`),
  KEY `host_discovery_1` (`parent_hostid`),
  KEY `host_discovery_2` (`parent_itemid`),
  CONSTRAINT `c_host_discovery_1` FOREIGN KEY (`hostid`) REFERENCES `hosts` (`hostid`) ON DELETE CASCADE,
  CONSTRAINT `c_host_discovery_2` FOREIGN KEY (`parent_hostid`) REFERENCES `hosts` (`hostid`),
  CONSTRAINT `c_host_discovery_3` FOREIGN KEY (`parent_itemid`) REFERENCES `items` (`itemid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `host_discovery`
--

LOCK TABLES `host_discovery` WRITE;
/*!40000 ALTER TABLE `host_discovery` DISABLE KEYS */;
INSERT INTO `host_discovery` VALUES (10333,NULL,31657,'',0,0,0,0,0),(10334,NULL,31658,'',0,0,0,0,0),(10367,NULL,32956,'',0,0,0,0,0),(10368,NULL,32957,'',0,0,0,0,0),(10388,NULL,33920,'',0,0,0,0,0),(10389,NULL,33923,'',0,0,0,0,0),(10511,NULL,40021,'',0,0,0,0,0),(10512,NULL,40023,'',0,0,0,0,0),(10513,NULL,40033,'',0,0,0,0,0),(10514,NULL,40035,'',0,0,0,0,0),(10523,NULL,43166,'',0,0,0,0,0),(10533,NULL,43768,'',0,0,0,0,0),(10536,NULL,44052,'',0,0,0,0,0),(10537,NULL,44053,'',0,0,0,0,0),(10538,NULL,44054,'',0,0,0,0,0),(10541,NULL,44200,'',0,0,0,0,0),(10545,NULL,44293,'',0,0,0,0,0),(10549,NULL,44314,'',0,0,0,0,0),(10550,NULL,44315,'',0,0,0,0,0),(10554,NULL,44468,'',0,0,0,0,0),(10559,NULL,44585,'',0,0,0,0,0),(10567,NULL,44733,'',0,0,0,0,0),(10569,NULL,44818,'',0,0,0,0,0),(10578,NULL,45034,'',0,0,0,0,0),(10579,NULL,45035,'',0,0,0,0,0),(10580,NULL,45036,'',0,0,0,0,0),(10581,NULL,45037,'',0,0,0,0,0),(10585,NULL,45595,'',0,0,0,0,0),(10588,NULL,45612,'',0,0,0,0,0),(10592,NULL,45787,'',0,0,0,0,0),(10597,NULL,46022,'',0,0,0,0,0),(10598,NULL,46023,'',0,0,0,0,0),(10601,NULL,46060,'',0,0,0,0,0),(10608,NULL,46503,'',0,0,0,0,0),(10612,NULL,46723,'',0,0,0,0,0),(10621,NULL,46933,'',0,0,0,0,0),(10622,NULL,46934,'',0,0,0,0,0),(10623,NULL,46935,'',0,0,0,0,0),(10624,NULL,46936,'',0,0,0,0,0),(10625,NULL,46937,'',0,0,0,0,0),(10626,NULL,46938,'',0,0,0,0,0),(10633,NULL,47499,'',0,0,0,0,0),(10635,NULL,47567,'',0,0,0,0,0),(10643,NULL,47929,'',0,0,0,0,0),(10644,NULL,47930,'',0,0,0,0,0),(10654,NULL,48471,'',0,0,0,0,0);
/*!40000 ALTER TABLE `host_discovery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:13

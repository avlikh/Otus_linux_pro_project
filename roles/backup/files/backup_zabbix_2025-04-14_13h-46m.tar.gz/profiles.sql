-- MySQL dump 10.13  Distrib 8.0.41, for Linux (x86_64)
--
-- Host: localhost    Database: zabbix
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profiles` (
  `profileid` bigint unsigned NOT NULL,
  `userid` bigint unsigned NOT NULL,
  `idx` varchar(96) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `idx2` bigint unsigned NOT NULL DEFAULT '0',
  `value_id` bigint unsigned NOT NULL DEFAULT '0',
  `value_int` int NOT NULL DEFAULT '0',
  `value_str` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `source` varchar(96) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `type` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`profileid`),
  KEY `profiles_1` (`userid`,`idx`,`idx2`),
  KEY `profiles_2` (`userid`,`profileid`),
  CONSTRAINT `c_profiles_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profiles`
--

LOCK TABLES `profiles` WRITE;
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
INSERT INTO `profiles` VALUES (1,1,'web.login.attempt.failed',0,0,0,'','',2),(2,1,'web.login.attempt.ip',0,0,0,'10.68.3.131','',3),(3,1,'web.login.attempt.clock',0,0,1744042223,'','',2),(4,1,'web.dashboard.dashboardid',0,1,0,'','',1),(5,1,'web.monitoring.problem.properties',0,0,0,'{\"filter_name\":\"\"}','',3),(6,1,'web.monitoring.problem.selected',0,0,0,'','',2),(7,1,'web.monitoring.problem.expanded',0,0,1,'','',2),(8,1,'web.monitoring.problem.expanded_timeselector',0,0,0,'','',2),(9,1,'web.hosts.sort',0,0,0,'name','',3),(10,1,'web.hosts.sortorder',0,0,0,'ASC','',3),(11,1,'web.pager.entity',0,0,0,'sysmaps.php','',3),(12,1,'web.pager.page',0,0,1,'','',2),(13,1,'web.charts.filter.hostids',0,10669,0,'','',1),(14,1,'web.charts.filter.name',0,0,0,'','',3),(15,1,'web.charts.filter.show',0,0,0,'','',2),(16,1,'web.charts.filter.from',0,0,0,'now-1h','',3),(17,1,'web.charts.filter.to',0,0,0,'now','',3),(18,1,'web.hostinventories.php.sort',0,0,0,'name','',3),(19,1,'web.hostinventories.php.sortorder',0,0,0,'ASC','',3),(20,1,'web.paging.lastpage',0,0,0,'sysmaps.php','',3),(22,1,'web.sysmaps.php.sort',0,0,0,'name','',3),(23,1,'web.sysmaps.php.sortorder',0,0,0,'ASC','',3),(48,1,'web.dashboard.last_widget_type',0,0,0,'map','',3),(51,1,'web.popup.generic.filter_hostid',0,10666,0,'','',1),(52,1,'web.hostinventories.filter_field',0,0,0,'alias','',3),(53,1,'web.hostinventories.filter_field_value',0,0,0,'','',3),(54,1,'web.hostinventories.filter_exact',0,0,0,'','',2),(55,1,'web.hostinventories.filter_groups',0,6,0,'','',1),(56,1,'web.monitoring.latest.properties',0,0,0,'{\"filter_name\":\"\",\"hostids\":[\"10669\"]}','',3),(57,1,'web.monitoring.latest.selected',0,0,0,'','',2),(58,1,'web.monitoring.latest.expanded',0,0,1,'','',2),(59,1,'web.monitoring.latest.expanded_timeselector',0,0,0,'','',2),(60,1,'web.item.graph.filter.from',49683,0,0,'now-1h','',3),(61,1,'web.item.graph.filter.to',49683,0,0,'now','',3),(62,1,'web.connector.list.sort',0,0,0,'name','',3),(63,1,'web.connector.list.sortorder',0,0,0,'ASC','',3),(64,1,'web.media_types.php.sort',0,0,0,'name','',3),(65,1,'web.media_types.php.sortorder',0,0,0,'ASC','',3),(66,1,'web.modules.sort',0,0,0,'name','',3),(67,1,'web.modules.sortorder',0,0,0,'ASC','',3),(68,1,'web.action.list.sort',0,0,0,'name','',3),(69,1,'web.action.list.sortorder',0,0,0,'ASC','',3),(70,1,'popup.condition.actions_last_type',0,0,0,'','',2),(71,1,'web.user.sort',0,0,0,'username','',3),(72,1,'web.user.sortorder',0,0,0,'ASC','',3),(73,1,'web.usergroup.sort',0,0,0,'name','',3),(74,1,'web.usergroup.sortorder',0,0,0,'ASC','',3),(75,1,'web.scripts.php.sort',0,0,0,'name','',3),(76,1,'web.scripts.php.sortorder',0,0,0,'ASC','',3),(79,1,'web.hosts.graphs.php.sort',0,0,0,'name','',3),(80,1,'web.hosts.graphs.php.sortorder',0,0,0,'ASC','',3),(81,1,'web.hosts.graphs.filter_hostids',0,10669,0,'','',1),(82,1,'web.hosts.trigger.list.sort',0,0,0,'description','',3),(83,1,'web.hosts.trigger.list.sortorder',0,0,0,'ASC','',3),(84,1,'web.hosts.trigger.list.filter_inherited',0,0,-1,'','',2),(85,1,'web.hosts.trigger.list.filter_discovered',0,0,-1,'','',2),(86,1,'web.hosts.trigger.list.filter_dependent',0,0,-1,'','',2),(87,1,'web.hosts.trigger.list.filter_name',0,0,0,'','',3),(88,1,'web.hosts.trigger.list.filter_hostids',0,10669,0,'','',1),(89,1,'web.hosts.trigger.list.filter_state',0,0,-1,'','',2),(90,1,'web.hosts.trigger.list.filter_status',0,0,-1,'','',2),(91,1,'web.hosts.trigger.list.filter.evaltype',0,0,0,'','',2),(92,1,'web.hosts.trigger.list.filter_value',0,0,-1,'','',2),(93,1,'web.hosts.items.list.filter_hostids',0,10666,0,'','',1),(94,1,'web.hosts.items.list.filter_name',0,0,0,'','',3),(95,1,'web.hosts.items.list.filter_type',0,0,-1,'','',2),(96,1,'web.hosts.items.list.filter_key',0,0,0,'','',3),(97,1,'web.hosts.items.list.filter_snmp_oid',0,0,0,'','',3),(98,1,'web.hosts.items.list.filter_value_type',0,0,-1,'','',2),(99,1,'web.hosts.items.list.filter_delay',0,0,0,'','',3),(100,1,'web.hosts.items.list.filter_history',0,0,0,'','',3),(101,1,'web.hosts.items.list.filter_trends',0,0,0,'','',3),(102,1,'web.hosts.items.list.filter_status',0,0,-1,'','',2),(103,1,'web.hosts.items.list.filter_state',0,0,-1,'','',2),(104,1,'web.hosts.items.list.filter_inherited',0,0,-1,'','',2),(105,1,'web.hosts.items.list.filter_with_triggers',0,0,-1,'','',2),(106,1,'web.hosts.items.list.filter_discovered',0,0,-1,'','',2),(107,1,'web.hosts.items.list.filter.evaltype',0,0,0,'','',2),(108,1,'web.host.dashboard.dashboardid',10670,17,0,'','',1),(109,1,'web.dashboard.filter.from',331,0,0,'now-2d','',3),(110,1,'web.dashboard.filter.to',331,0,0,'now','',3),(111,1,'web.dashboard.filter.from',140,0,0,'now-1h','',3),(112,1,'web.dashboard.filter.to',140,0,0,'now','',3),(113,1,'web.dashboard.filter.from',17,0,0,'now-2d','',3),(114,1,'web.dashboard.filter.to',17,0,0,'now','',3),(115,1,'web.dashboard.filter.httptestid',0,17,0,'','',1),(117,1,'web.dashboard.filter.httptestid',0,17,0,'','',1),(118,1,'web.host.dashboard.dashboardid',10667,17,0,'','',1),(119,1,'web.host.dashboard.dashboardid',10668,331,0,'','',1),(120,1,'web.host.dashboard.dashboardid',10666,17,0,'','',1),(121,1,'web.host.dashboard.dashboardid',10665,17,0,'','',1),(123,1,'web.popup.generic.filter_templategroupid',0,10,0,'','',1),(124,1,'web.popup.generic.filter_groupid',0,6,0,'','',1),(133,1,'web.favorite.sysmapids',0,2,0,'','sysmapid',1),(134,1,'web.layout.mode',0,0,0,'','',2),(159,1,'web.host.dashboard.dashboardid',10084,331,0,'','',1),(160,1,'web.dashboard.filter.from',36,0,0,'now-1h','',3),(161,1,'web.dashboard.filter.to',36,0,0,'now','',3),(172,1,'web.maps.sysmapid',0,2,0,'','',1);
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'zabbix'
--

--
-- Dumping routines for database 'zabbix'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-14 13:46:17
